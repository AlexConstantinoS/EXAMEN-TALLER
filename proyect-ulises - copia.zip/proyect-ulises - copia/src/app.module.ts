import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ControladoresController } from './controladores/controladores.controller';
import { ServiciosService } from './servicios/servicios.service';
import { ModuloModule } from './modulo/modulo.module';

@Module({
  imports: [ModuloModule],
  controllers: [AppController, ControladoresController],
  providers: [AppService, ServiciosService],
})
export class AppModule {}
