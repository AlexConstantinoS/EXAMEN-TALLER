import { Controller } from '@nestjs/common';

@Controller('controladores')
export class ControladoresController {}
