export interface Interfaz {}
