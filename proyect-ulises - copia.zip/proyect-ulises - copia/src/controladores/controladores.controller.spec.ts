import { Test, TestingModule } from '@nestjs/testing';
import { ControladoresController } from './controladores.controller';

describe('ControladoresController', () => {
  let controller: ControladoresController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ControladoresController],
    }).compile();

    controller = module.get<ControladoresController>(ControladoresController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
